import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Dict, Optional

import httpx
import pandas as pd

import os
import hashlib
import hmac
import json
from news_engine import snapshot as news_snapshot, apply_to_signal as apply_news_to_signal

MODE = os.getenv('BYBIT_MODE', 'paper').lower()
if MODE not in ('paper', 'demo', 'live'):
    MODE = 'paper'
BASE = {'demo':'https://api-demo.bybit.com', 'live':'https://api.bybit.com', 'paper':'https://api-testnet.bybit.com'}[MODE]
DEMO_API_KEY = os.getenv('BYBIT_DEMO_API_KEY', '')
DEMO_API_SECRET = os.getenv('BYBIT_DEMO_API_SECRET', '')
LIVE_API_KEY = os.getenv('BYBIT_LIVE_API_KEY', '')
LIVE_API_SECRET = os.getenv('BYBIT_LIVE_API_SECRET', '')
LIVE_TRADING_ARMED = os.getenv('LIVE_TRADING_ARMED', 'false').lower() == 'true'
TIMEOUT = 10.0
# Keep REST safely below endpoint/UID limits. The scanner should prefer cache/WS over bursts.
CACHE_TTL = 60.0
REST_MIN_INTERVAL_SEC = float(os.getenv('REST_MIN_INTERVAL_SEC', '0.12'))
RETRY_COUNT = 2
PRIVATE_RETRY_COUNT = 2
DEMO_ACCOUNT_CACHE_TTL = 8.0
DEMO_CLOSED_PNL_CACHE_TTL = 30.0
MAX_POSITIONS = int(os.getenv('MAX_POSITIONS', '8'))
RISK_PCT_DEFAULT = float(os.getenv('RISK_PCT_DEFAULT', '2'))
LEVERAGE = float(os.getenv('DEFAULT_LEVERAGE', '10'))
LEVERAGE_MODE = os.getenv('LEVERAGE_MODE', 'fixed').lower()
TOTAL_OPEN_RISK_PCT = float(os.getenv('TOTAL_OPEN_RISK_PCT', '8'))
START_BALANCE = 10.0
DEMO_TRADING_BUDGET = float(os.getenv('DEMO_TRADING_BUDGET', '10000'))
DEMO_MAX_DAILY_LOSS = float(os.getenv('DEMO_MAX_DAILY_LOSS', '20'))
DEMO_RISK_PCT = float(os.getenv('DEMO_RISK_PCT', '2'))
LIVE_TRADING_BUDGET = float(os.getenv('LIVE_TRADING_BUDGET', '100'))
LIVE_MAX_DAILY_LOSS = float(os.getenv('LIVE_MAX_DAILY_LOSS', '20'))
LIVE_RISK_PCT = float(os.getenv('LIVE_RISK_PCT', '2'))
BOT_BASE_CAPITAL = float(os.getenv('BOT_BASE_CAPITAL', '10000'))
PROFIT_LOCK_STEP = float(os.getenv('PROFIT_LOCK_STEP', '5'))
BOT_CAPITAL_MIN = float(os.getenv('BOT_CAPITAL_MIN', '1'))
BOT_CAPITAL_MAX = float(os.getenv('BOT_CAPITAL_MAX', '1000000'))

# Scan budget: broad market discovery is one ticker request; expensive candle/microstructure
# calls are reserved for a small ranked subset.
TECH_CANDIDATES = int(os.getenv('TECH_CANDIDATES', '24'))
DEEP_CANDIDATES = int(os.getenv('DEEP_CANDIDATES', '12'))
MICRO_CANDIDATES = int(os.getenv('MICRO_CANDIDATES', '8'))
FULL_MARKET_DEEP_CANDIDATES = int(os.getenv('FULL_MARKET_DEEP_CANDIDATES', '30'))
FULL_MARKET_DEFAULT = os.getenv('FULL_MARKET_DEFAULT', 'true').lower() == 'true'
FULL_MARKET_WORKERS = int(os.getenv('FULL_MARKET_WORKERS', '6'))
INSTRUMENT_CACHE_TTL = 600.0
DAILY_LOSS_LIMIT_PCT = 6.0
MAX_CONSECUTIVE_LOSSES = 3
LOSS_COOLDOWN_SEC = 30 * 60
ENTRY_SCORE_MIN = 70
ENTRY_RR_MIN = float(os.getenv('ENTRY_RR_MIN', '1.5'))
SCALP_TIME_STOP_MIN = int(os.getenv('SCALP_TIME_STOP_MIN', '15'))
MAX_MARGIN_FRACTION = 0.95
# Simulation assumptions only; change them when you know the fee/slippage model you want.
PAPER_FEE_RATE = 0.00055
PAPER_SLIPPAGE_RATE = 0.0002

_lock = threading.RLock()
_rest_rate_lock = threading.Lock()
_rest_last_request = 0.0
_http = httpx.Client(timeout=TIMEOUT, headers={'User-Agent': 'BybitAI-Agent/6.0.0'}, limits=httpx.Limits(max_connections=40, max_keepalive_connections=20))
_cache = {}
_state = {
    'balance': START_BALANCE,
    'trading_budget': START_BALANCE,
    'reserved_margin': 0.0,
    'initial_balance': START_BALANCE,
    'trades': [],
    'open': [],
    'day': datetime.now(timezone.utc).date().isoformat(),
    'day_start_balance': START_BALANCE,
    'loss_streak': 0,
    'last_loss_at': 0,
    'peak_equity': START_BALANCE,
    'mark_prices': {},
}

_demo_guard = {'day': datetime.now(timezone.utc).date().isoformat(), 'start_equity': None}


def _cached(key):
    item = _cache.get(key)
    if item and time.time() - item[0] < CACHE_TTL:
        return item[1]
    return None


def _put_cache(key, value):
    _cache[key] = (time.time(), value)
    return value


def _auth_headers(method, path, payload):
    if MODE == 'demo':
        key, secret = DEMO_API_KEY, DEMO_API_SECRET
    elif MODE == 'live':
        key, secret = LIVE_API_KEY, LIVE_API_SECRET
    else:
        return {}
    if not key or not secret:
        return {}
    ts = str(int(time.time() * 1000)); recv = '5000'
    from urllib.parse import urlencode
    body = urlencode(sorted(payload.items())) if method == 'GET' else json.dumps(payload, separators=(',', ':'))
    sign = hmac.new(secret.encode(), (ts + key + recv + body).encode(), hashlib.sha256).hexdigest()
    return {'X-BAPI-API-KEY': key, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': sign}

def _pace_rest():
    global _rest_last_request
    with _rest_rate_lock:
        now = time.monotonic()
        wait = REST_MIN_INTERVAL_SEC - (now - _rest_last_request)
        if wait > 0:
            time.sleep(wait)
        _rest_last_request = time.monotonic()


def bybit_get(path, params):
    key = (MODE, path, tuple(sorted((str(k), str(v)) for k, v in params.items())))
    cached = _cached(key)
    if cached is not None: return cached
    last_error = None
    for attempt in range(RETRY_COUNT + 1):
        try:
            _pace_rest()
            r = _http.get(BASE + path, params=params, headers=_auth_headers('GET', path, params))
            if r.status_code in (429, 500, 502, 503, 504) and attempt < RETRY_COUNT:
                retry_after = getattr(r, 'headers', {}).get('Retry-After')
                try:
                    delay = max(0.5, min(5.0, float(retry_after))) if retry_after else 0.8 * (2 ** attempt)
                except ValueError:
                    delay = 0.8 * (2 ** attempt)
                time.sleep(delay); continue
            r.raise_for_status()
            try:
                j = r.json()
            except ValueError:
                raise RuntimeError(f'Bybit returned invalid JSON (HTTP {r.status_code})')
            if j.get('retCode') != 0:
                raise RuntimeError(f"Bybit {j.get('retCode')}: {j.get('retMsg', 'API error')}")
            return _put_cache(key, j.get('result', {}))
        except httpx.HTTPStatusError as e:
            last_error = RuntimeError(f'Bybit HTTP {e.response.status_code}')
        except httpx.RequestError as e:
            last_error = RuntimeError(f'Bybit connection error: {e}')
        except RuntimeError as e:
            last_error = e
        if attempt < RETRY_COUNT:
            time.sleep(0.45 * (2 ** attempt))
    raise last_error or RuntimeError('Bybit request failed')

def bybit_private_post(path, body, allow_ret_codes=None):
    if MODE == 'demo':
        key, secret = DEMO_API_KEY, DEMO_API_SECRET
    elif MODE == 'live':
        if not LIVE_TRADING_ARMED: raise RuntimeError('LIVE trading is not armed')
        key, secret = LIVE_API_KEY, LIVE_API_SECRET
    else:
        raise RuntimeError('Private Bybit API is disabled in paper mode')
    if not key or not secret: raise RuntimeError(f'{MODE.upper()} API key/secret are not configured')
    allow_ret_codes = {int(x) for x in (allow_ret_codes or ())}
    # Never blindly retry order creation: a network timeout can happen after Bybit accepted
    # the order, and a retry could create a duplicate. Non-order control endpoints are safe
    # to retry on transient transport/server failures.
    attempts = 1 if path == '/v5/order/create' else (PRIVATE_RETRY_COUNT + 1)
    last_error = None
    for attempt in range(attempts):
        try:
            _pace_rest()
            r = _http.post(BASE + path, json=body, headers={**_auth_headers('POST', path, body), 'Content-Type':'application/json'})
            if r.status_code in (429, 500, 502, 503, 504) and attempt + 1 < attempts:
                retry_after = getattr(r, 'headers', {}).get('Retry-After')
                try:
                    delay = max(0.5, min(5.0, float(retry_after))) if retry_after else 0.8 * (2 ** attempt)
                except ValueError:
                    delay = 0.8 * (2 ** attempt)
                time.sleep(delay); continue
            r.raise_for_status()
            try:
                j = r.json()
            except ValueError:
                raise RuntimeError(f'Bybit returned invalid JSON (HTTP {r.status_code})')
            ret_code = int(j.get('retCode', 0))
            if ret_code != 0 and ret_code not in allow_ret_codes:
                raise RuntimeError(f"Bybit {ret_code}: {j.get('retMsg', 'API error')}")
            return j.get('result', {})
        except httpx.HTTPStatusError as e:
            last_error = RuntimeError(f'Bybit HTTP {e.response.status_code}')
        except httpx.RequestError as e:
            last_error = RuntimeError(f'Bybit connection error: {e}')
        except RuntimeError as e:
            last_error = e
        if attempt + 1 < attempts:
            time.sleep(0.45 * (2 ** attempt))
    raise last_error or RuntimeError('Bybit private request failed')


def tickers():
    return bybit_get('/v5/market/tickers', {'category': 'linear'}).get('list', [])


def instruments():
    key = ('__instruments__',)
    item = _cache.get(key)
    if item and time.time() - item[0] < INSTRUMENT_CACHE_TTL:
        return item[1]
    result = []
    cursor = None
    for _ in range(10):
        p = {'category': 'linear', 'status': 'Trading', 'limit': 1000}
        if cursor:
            p['cursor'] = cursor
        j = bybit_get('/v5/market/instruments-info', p)
        result += j.get('list', [])
        cursor = j.get('nextPageCursor')
        if not cursor:
            break
    out = [x for x in result if x.get('contractType') == 'LinearPerpetual'
           and x.get('quoteCoin') == 'USDT' and x.get('settleCoin') == 'USDT']
    _cache[key] = (time.time(), out)
    return out


def market_snapshot(limit=20):
    allowed = {x.get('symbol') for x in instruments() if x.get('symbol')}
    rows = []
    for x in tickers():
        symbol = x.get('symbol', '')
        if symbol not in allowed:
            continue
        try:
            bid = float(x.get('bid1Price') or 0)
            ask = float(x.get('ask1Price') or 0)
            last = float(x.get('lastPrice') or 0)
            spread_pct = ((ask - bid) / last * 100) if last > 0 and ask >= bid > 0 else None
            rows.append({
                'symbol': symbol, 'lastPrice': last,
                'turnover24h': float(x.get('turnover24h') or 0),
                'price24hPcnt': float(x.get('price24hPcnt') or 0) * 100,
                'highPrice24h': float(x.get('highPrice24h') or 0),
                'lowPrice24h': float(x.get('lowPrice24h') or 0),
                'volume24h': float(x.get('volume24h') or 0),
                'fundingRate': float(x.get('fundingRate') or 0),
                'openInterest': float(x.get('openInterest') or 0),
                'spreadPct': spread_pct,
            })
        except (TypeError, ValueError):
            continue
    rows.sort(key=lambda x: x['turnover24h'], reverse=True)
    cap = max(1, min(int(limit), 100))
    return rows[:cap]

def klines(symbol, interval, limit=220):
    # Shared TTL cache is critical because NORMAL and SCALP consume the same higher-timeframe data.
    # The cache also prevents rapid UI polling from re-fetching identical candles.
    key = ('klines', symbol, str(interval), int(limit))
    cached = _cached(key)
    if cached is not None:
        return cached.copy(deep=True)
    rows = bybit_get('/v5/market/kline', {
        'category': 'linear', 'symbol': symbol, 'interval': str(interval), 'limit': min(int(limit), 1000)
    }).get('list', [])
    if len(rows) < 65:
        raise RuntimeError(f'Not enough candles for {symbol} {interval}m')
    rows = list(reversed(rows))
    df = pd.DataFrame(rows, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'turnover'])
    for c in ['open', 'high', 'low', 'close', 'volume', 'turnover']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df['timestamp'] = pd.to_numeric(df['timestamp'], errors='coerce')
    df = df.dropna().reset_index(drop=True)
    out = df.iloc[:-1].reset_index(drop=True)  # closed candles only
    _put_cache(key, out)
    return out.copy(deep=True)


def open_interest(symbol, interval='15min', limit=10):
    return bybit_get('/v5/market/open-interest', {
        'category': 'linear', 'symbol': symbol, 'intervalTime': interval, 'limit': min(int(limit), 200)
    }).get('list', [])


def orderbook(symbol, limit=50):
    return bybit_get('/v5/market/orderbook', {
        'category': 'linear', 'symbol': symbol, 'limit': min(int(limit), 1000)
    })


def recent_trades(symbol, limit=500):
    return bybit_get('/v5/market/recent-trade', {
        'category': 'linear', 'symbol': symbol, 'limit': min(int(limit), 1000)
    }).get('list', [])


def funding_history(symbol, limit=1):
    return bybit_get('/v5/market/funding/history', {
        'category': 'linear', 'symbol': symbol, 'limit': min(int(limit), 200)
    }).get('list', [])


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def atr(df, n=14):
    prev = df.close.shift(1)
    tr = pd.concat([(df.high - df.low), (df.high - prev).abs(), (df.low - prev).abs()], axis=1).max(axis=1)
    return tr.rolling(n).mean()


def rsi(s, n=14):
    d = s.diff()
    g = d.clip(lower=0).rolling(n).mean()
    l = (-d.clip(upper=0)).rolling(n).mean()
    rs = g / l.replace(0, float('nan'))
    return (100 - (100 / (1 + rs))).fillna(50)


def vwap(df):
    return (df.close * df.volume).cumsum() / df.volume.cumsum().replace(0, float('nan'))


def frame_features(df):
    x = df.copy()
    x['ema20'] = ema(x.close, 20)
    x['ema50'] = ema(x.close, 50)
    x['rsi'] = rsi(x.close)
    x['atr'] = atr(x)
    x['vwap'] = vwap(x)
    x['vol_ma20'] = x.volume.rolling(20).mean()
    x['atr_pct'] = x.atr / x.close.replace(0, float('nan')) * 100
    return x


def bias(df):
    x = frame_features(df)
    z = x.iloc[-1]
    if z.ema20 > z.ema50 and z.close > z.ema20:
        return 'LONG'
    if z.ema20 < z.ema50 and z.close < z.ema20:
        return 'SHORT'
    return 'NEUTRAL'


def sweep(df, lookback=20):
    if len(df) < lookback + 2:
        return False, False
    last = df.iloc[-1]
    prior = df.iloc[-lookback-1:-1]
    return bool(last.low < prior.low.min() and last.close > prior.low.min()), bool(last.high > prior.high.max() and last.close < prior.high.max())


def structure_confirmation(df, lookback=5):
    if len(df) < lookback + 2:
        return False, False
    last = df.iloc[-1]
    prev = df.iloc[-lookback-1:-1]
    return bool(last.close > prev.high.max()), bool(last.close < prev.low.min())


def flow_features(symbol):
    out = {'oi_change_pct': 0.0, 'orderbook_imbalance': 0.0, 'trade_delta_pct': 0.0,
           'funding_rate': 0.0, 'spread_pct': None}
    try:
        oi = open_interest(symbol, '15min', 10)
        vals = [float(x.get('openInterest') or 0) for x in oi if float(x.get('openInterest') or 0) > 0]
        # Bybit returns the newest OI observation first.
        if len(vals) >= 2 and vals[-1] > 0:
            out['oi_change_pct'] = (vals[0] / vals[-1] - 1) * 100
    except Exception:
        pass
    try:
        ob = orderbook(symbol, 50)
        bids = [(float(p), float(q)) for p, q in ob.get('b', []) if float(p) > 0 and float(q) >= 0]
        asks = [(float(p), float(q)) for p, q in ob.get('a', []) if float(p) > 0 and float(q) >= 0]
        bn = sum(p * q for p, q in bids[:20]); an = sum(p * q for p, q in asks[:20])
        if bn + an > 0:
            out['orderbook_imbalance'] = (bn - an) / (bn + an) * 100
        if bids and asks:
            mid = (bids[0][0] + asks[0][0]) / 2
            if mid > 0:
                out['spread_pct'] = (asks[0][0] - bids[0][0]) / mid * 100
    except Exception:
        pass
    try:
        trades = recent_trades(symbol, 500)
        buy = sum(float(x.get('size') or 0) for x in trades if x.get('side') == 'Buy')
        sell = sum(float(x.get('size') or 0) for x in trades if x.get('side') == 'Sell')
        if buy + sell > 0:
            out['trade_delta_pct'] = (buy - sell) / (buy + sell) * 100
    except Exception:
        pass
    try:
        fr = funding_history(symbol, 1)
        if fr:
            out['funding_rate'] = float(fr[0].get('fundingRate') or 0)
    except Exception:
        pass
    return out


def score(frames, setup='15', micro=None, live_price=None, btc_context=None, entry_threshold=ENTRY_SCORE_MIN, strategy='normal'):
    if setup not in frames:
        raise ValueError('unsupported setup timeframe')
    f = {k: frame_features(v) for k, v in frames.items()}
    bd = bias(frames['D']) if 'D' in frames else 'NEUTRAL'
    b4, b1 = bias(frames['240']), bias(frames['60'])
    setup_df = f[setup]; z = setup_df.iloc[-1]
    hi, lo = setup_df.high.tail(50).max(), setup_df.low.tail(50).min()
    rng = max(float(hi - lo), 1e-12); pos = (float(z.close) - float(lo)) / rng
    bull_sweep, bear_sweep = sweep(frames[setup])
    bull_break, bear_break = structure_confirmation(frames[setup])
    micro = micro or {}
    oi_chg = float(micro.get('oi_change_pct') or 0); ob_imb = float(micro.get('orderbook_imbalance') or 0)
    delta = float(micro.get('trade_delta_pct') or 0); funding = float(micro.get('funding_rate') or 0)
    spread = micro.get('spread_pct')
    ls = ss = 0.0; reasons_long, reasons_short = [], []
    if bd == 'LONG': ls += 10; reasons_long.append('1D trend')
    elif bd == 'SHORT': ss += 10; reasons_short.append('1D trend')
    if b4 == 'LONG': ls += 20; reasons_long.append('4H trend')
    elif b4 == 'SHORT': ss += 20; reasons_short.append('4H trend')
    if b1 == 'LONG': ls += 15; reasons_long.append('1H trend')
    elif b1 == 'SHORT': ss += 15; reasons_short.append('1H trend')
    if bull_sweep: ls += 12; reasons_long.append('liquidity sweep')
    if bear_sweep: ss += 12; reasons_short.append('liquidity sweep')
    if bull_break: ls += 10; reasons_long.append('structure break')
    if bear_break: ss += 10; reasons_short.append('structure break')
    if pos <= 0.45: ls += 8; reasons_long.append('discount')
    elif pos >= 0.55: ss += 8; reasons_short.append('premium')
    if z.close > z.vwap: ls += 5; reasons_long.append('above VWAP')
    elif z.close < z.vwap: ss += 5; reasons_short.append('below VWAP')
    if pd.notna(z.vol_ma20) and z.volume > z.vol_ma20 * 1.05:
        if z.close >= z.open: ls += 5; reasons_long.append('volume confirmation')
        else: ss += 5; reasons_short.append('volume confirmation')
    z5 = f['5'].iloc[-1]
    if z5.close > z5.ema20: ls += 5; reasons_long.append('5M momentum')
    elif z5.close < z5.ema20: ss += 5; reasons_short.append('5M momentum')
    if 52 <= z.rsi <= 68: ls += 5; reasons_long.append('RSI confirmation')
    elif 32 <= z.rsi <= 48: ss += 5; reasons_short.append('RSI confirmation')
    if oi_chg > 1.0: ls += 5; reasons_long.append('OI rising')
    elif oi_chg < -1.0: ss += 5; reasons_short.append('OI falling')
    if ob_imb > 8: ls += 4; reasons_long.append('bid imbalance')
    elif ob_imb < -8: ss += 4; reasons_short.append('ask imbalance')
    if delta > 8: ls += 6; reasons_long.append('buy delta')
    elif delta < -8: ss += 6; reasons_short.append('sell delta')

    atrv = float(z.atr) if pd.notna(z.atr) and z.atr > 0 else max(float(z.close) * 0.003, 1e-9)
    atr_pct = float(z.atr_pct) if pd.notna(z.atr_pct) else 0.0
    extension = abs(float(z.close) - float(z.ema20)) / atrv
    if extension > 1.8:
        if z.close > z.ema20: ls = max(0.0, ls - 10); reasons_long.append('overextended -10')
        else: ss = max(0.0, ss - 10); reasons_short.append('overextended -10')
    if funding > 0.0015:
        ls = max(0.0, ls - 3); reasons_long.append('funding crowded -3')
    elif funding < -0.0015:
        ss = max(0.0, ss - 3); reasons_short.append('funding crowded -3')

    spread_bad = spread is not None and spread > 0.12
    if spread_bad:
        ls = max(0.0, ls - 8); ss = max(0.0, ss - 8)
        reasons_long.append('wide spread -8'); reasons_short.append('wide spread -8')

    # Avoid dead markets and abnormal spikes for a short-horizon setup.
    volatility_bad = atr_pct > 5.0 or (atr_pct > 0 and atr_pct < 0.08)
    if volatility_bad:
        ls = max(0.0, ls - 8); ss = max(0.0, ss - 8)

    btc_block_long = bool(btc_context and btc_context.get('symbol') != 'BTCUSDT' and btc_context.get('b4') == 'SHORT' and btc_context.get('b1') == 'SHORT')
    btc_block_short = bool(btc_context and btc_context.get('symbol') != 'BTCUSDT' and btc_context.get('b4') == 'LONG' and btc_context.get('b1') == 'LONG')
    if btc_block_long: ls = max(0.0, ls - 15); reasons_long.append('BTC risk-off -15')
    if btc_block_short: ss = max(0.0, ss - 15); reasons_short.append('BTC risk-on -15')

    price = float(live_price if live_price and live_price > 0 else z.close)
    # Build structural stop/target before deciding. This lets the entry gate reject
    # trades with poor geometry rather than treating a high market score as permission.
    long_sl = min(float(z.low), float(frames[setup].low.tail(20).min())) - 0.15 * atrv
    long_tp = price + 2 * max(price - long_sl, atrv * 0.5)
    short_sl = max(float(z.high), float(frames[setup].high.tail(20).max())) + 0.15 * atrv
    short_tp = price - 2 * max(short_sl - price, atrv * 0.5)
    long_rr = ((long_tp - price) / (price - long_sl)) if long_sl < price else 0.0
    short_rr = ((price - short_tp) / (short_sl - price)) if short_sl > price else 0.0
    spread_cost = max(float(spread or 0), 0.0) / 100.0
    round_trip_cost = 2 * (PAPER_FEE_RATE + PAPER_SLIPPAGE_RATE) + spread_cost
    long_net_edge = max(0.0, (long_tp - price) / max(price, 1e-12) - round_trip_cost)
    short_net_edge = max(0.0, (price - short_tp) / max(price, 1e-12) - round_trip_cost)

    def blockers(side):
        out=[]
        is_long=side=='LONG'
        # Hard blockers are intentionally limited. Most market signals are soft
        # evidence that affects score rather than binary gates, otherwise a valid
        # setup can be rejected by one noisy microstructure reading.
        if b4 == ('SHORT' if is_long else 'LONG'): out.append('4H trend против')
        if b1 == ('SHORT' if is_long else 'LONG'): out.append('1H trend против')
        if is_long:
            if not (bull_sweep or bull_break): out.append('нет подтверждения структуры')
        else:
            if not (bear_sweep or bear_break): out.append('нет подтверждения структуры')
        if spread_bad: out.append('широкий spread')
        if volatility_bad: out.append('аномальная волатильность')
        if is_long and btc_block_long: out.append('BTC risk-off')
        if not is_long and btc_block_short: out.append('BTC risk-on')
        rr = long_rr if is_long else short_rr
        net = long_net_edge if is_long else short_net_edge
        if rr < ENTRY_RR_MIN: out.append(f'R:R ниже {ENTRY_RR_MIN:g}')
        if net <= 0: out.append('ожидаемый net edge после расходов ≤ 0')
        if (ls if is_long else ss) < float(entry_threshold): out.append(f'score ниже {int(entry_threshold)}')
        return out

    best = max(ls, ss)
    candidate = 'LONG' if ls > ss else ('SHORT' if ss > ls else 'WAIT')
    long_blockers = blockers('LONG'); short_blockers = blockers('SHORT')
    long_gate = not long_blockers
    short_gate = not short_blockers
    direction = 'LONG' if candidate=='LONG' and long_gate else ('SHORT' if candidate=='SHORT' and short_gate else 'WAIT')
    if direction == 'LONG':
        sl, tp, rr, reasons = long_sl, long_tp, long_rr, reasons_long
    elif direction == 'SHORT':
        sl, tp, rr, reasons = short_sl, short_tp, short_rr, reasons_short
    else:
        sl = tp = rr = None
        reasons = reasons_long if candidate=='LONG' else reasons_short if candidate=='SHORT' else []
    blockers_out = long_blockers if candidate=='LONG' else short_blockers if candidate=='SHORT' else ['нет явного directional перевеса']
    if direction == 'WAIT': reasons = list(reasons) + ['BLOCK: '+x for x in blockers_out]
    regime = 'HIGH_VOLATILITY' if atr_pct > 5 else ('LOW_VOLATILITY' if 0 < atr_pct < 0.08 else ('TREND_UP' if b4=='LONG' and b1=='LONG' else 'TREND_DOWN' if b4=='SHORT' and b1=='SHORT' else 'RANGE'))
    timing = 'NOW' if direction in ('LONG','SHORT') else ('BREAKOUT' if 'нет подтверждения структуры' in blockers_out else 'WAIT')
    if candidate=='LONG' and pos > 0.50: timing='PULLBACK'
    if candidate=='SHORT' and pos < 0.50: timing='PULLBACK'
    quality = 'A+' if direction in ('LONG','SHORT') and best >= float(entry_threshold)+10 else ('A' if direction in ('LONG','SHORT') else 'WAIT')
    return {
        'direction': direction, 'signal_direction': candidate, 'score': round(min(100.0, float(best)), 1),
        'entry_score': round(min(100.0, float(best)), 1), 'entry_threshold': int(entry_threshold),
        'signal_quality': quality, 'decision': f'OPEN {direction}' if direction in ('LONG','SHORT') else 'WAIT',
        'entry_timing': timing, 'market_regime': regime, 'blockers': blockers_out,
        'price': price, 'stop_loss': sl, 'take_profit': tp, 'rr': round(rr,2) if rr is not None else None,
        'expected_net_edge_pct': round((long_net_edge if candidate=='LONG' else short_net_edge)*100, 4),
        'htf_1d': bd, 'htf_4h': b4, 'htf_1h': b1, 'setup_tf': setup,
        'bull_sweep': bull_sweep, 'bear_sweep': bear_sweep, 'bull_structure_break': bull_break, 'bear_structure_break': bear_break,
        'entry_gate_long': long_gate, 'entry_gate_short': short_gate, 'range_position': round(pos, 3), 'atr_pct': round(atr_pct, 3),
        'reasons': reasons, 'long_score': round(min(100.0, ls), 1), 'short_score': round(min(100.0, ss), 1),
        'oi_change_pct': round(oi_chg, 2), 'orderbook_imbalance': round(ob_imb, 2), 'trade_delta_pct': round(delta, 2),
        'funding_rate': funding, 'spread_pct': round(spread, 4) if spread is not None else None,
        'scalp_time_stop_min': SCALP_TIME_STOP_MIN if strategy=='scalp' else None,
    }


def _scan_one(symbol, setup, live_price, micro=None, btc_context=None):
    frames = {k: klines(symbol, k, 220) for k in ['5', '15', '60', '240', 'D']}
    return score(frames, setup, micro=micro, live_price=live_price, btc_context=btc_context)


def _ticker_map():
    return {x.get('symbol'): x for x in tickers() if x.get('symbol')}


def _fast_market_universe():
    allowed = {x.get('symbol') for x in instruments() if x.get('symbol')}
    tm = _ticker_map()
    rows = []
    for symbol, x in tm.items():
        if symbol not in allowed:
            continue
        try:
            turnover = float(x.get('turnover24h') or 0)
            last = float(x.get('lastPrice') or 0)
            bid = float(x.get('bid1Price') or 0); ask = float(x.get('ask1Price') or 0)
            spread = ((ask-bid)/last*100) if last > 0 and ask >= bid > 0 else 999.0
            chg = abs(float(x.get('price24hPcnt') or 0))*100
            # Analyze every active USDT linear perpetual. Liquidity/spread are trade gates,
            # not discovery filters; a thin market must remain visible to the analysis layer.
            if last <= 0:
                continue
            rows.append({'symbol': symbol, 'turnover24h': turnover, 'lastPrice': last,
                         'spreadPct': spread, 'absChange24h': chg,
                         'price24hPcnt': float(x.get('price24hPcnt') or 0)*100})
        except (TypeError, ValueError):
            continue
    rows.sort(key=lambda x: (x['turnover24h'], -x['spreadPct']), reverse=True)
    return rows, tm


def _technical_one(symbol, interval, tm):
    """Zero-candle fast pass for the whole market.

    The full universe is analysed from the live ticker snapshot first. Expensive
    multi-timeframe candles are reserved for the deep shortlist. This avoids
    hundreds of REST kline requests every cycle and prevents HTTP 429 bursts.
    """
    row = tm.get(symbol) or {}
    price = float(row.get('lastPrice') or 0)
    change = float(row.get('price24hPcnt') or 0) * 100
    turnover = float(row.get('turnover24h') or 0)
    bid = float(row.get('bid1Price') or 0); ask = float(row.get('ask1Price') or 0)
    spread = ((ask - bid) / price * 100) if price > 0 and ask >= bid > 0 else 999.0
    # Directional hint is intentionally weak: it only ranks candidates for deep analysis.
    hint = min(45.0, abs(change) * 2.0)
    if turnover > 0:
        hint += min(15.0, math.log10(turnover + 1.0))
    return {
        'symbol': symbol, 'price': price, 'turnover24h': turnover, 'spreadPct': spread,
        'htf_1d': 'UNKNOWN', 'htf_4h': 'UNKNOWN', 'htf_1h': 'UNKNOWN',
        'hint': round(hint, 3), 'frames': None, 'fast_change_24h': change,
    }

def _deep_one(item, interval, btc_context, entry_threshold=ENTRY_SCORE_MIN, strategy='normal'):
    symbol=item['symbol']
    # Deep analysis is bounded. Five timeframes are fetched once and then served
    # from the shared 60s cache to both NORMAL and SCALP when the same symbol is used.
    frames = {k: klines(symbol, k, 180) for k in ('5', '15', '60', '240', 'D')}
    return score(frames, interval, micro=None, live_price=item['price'], btc_context=btc_context, entry_threshold=entry_threshold, strategy=strategy)


def _json_safe(value):
    # Convert numpy/pandas scalar values and non-finite floats before FastAPI serialisation.
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if hasattr(value, 'item'):
        try:
            return _json_safe(value.item())
        except Exception:
            pass
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return str(value)


def scan_market(interval='15', limit_symbols=0, entry_threshold=ENTRY_SCORE_MIN, strategy='normal', full_market=None):
    if interval not in {'5', '15', '60'}:
        raise ValueError('interval must be 5, 15 or 60')
    universe, tm = _fast_market_universe()
    if not universe:
        return {'ok': True, 'mode':MODE, 'setup_interval':interval, 'universe_size':0, 'checked':0, 'technical_checked':0, 'deep_checked':0, 'micro_checked':0, 'results':[], 'failures':[], 'news': news_snapshot()}

    # Full-market mode is the default. A finite limit remains available for diagnostics,
    # but it is no longer the trading architecture's hidden 24-symbol bottleneck.
    if full_market is None:
        full_market = FULL_MARKET_DEFAULT or not limit_symbols
    if full_market:
        top = list(universe)
    else:
        top = universe[:max(1, int(limit_symbols))]
    btc_row = next((x for x in universe if x['symbol']=='BTCUSDT'), None)
    if btc_row and all(x['symbol']!='BTCUSDT' for x in top):
        top.append(btc_row)

    preliminary=[]; failures=[]
    with ThreadPoolExecutor(max_workers=max(2, FULL_MARKET_WORKERS)) as ex:
        futures={ex.submit(_technical_one,x['symbol'],interval,tm):x['symbol'] for x in top}
        for fut in as_completed(futures):
            s=futures[fut]
            try:
                preliminary.append(fut.result())
            except Exception as first_error:
                # A single candle request can fail transiently even when the public API is healthy.
                # Retry the symbol once outside the pool so one blip does not poison the whole scan.
                try:
                    preliminary.append(_technical_one(s, interval, tm))
                except Exception as second_error:
                    failures.append({'symbol':s,'stage':'technical','error':str(second_error),'retry_error':str(first_error)})
    preliminary.sort(key=lambda x:(x['hint'], x['turnover24h']), reverse=True)

    # Full-market means every active symbol gets a fast technical analysis. Deep analysis is
    # intentionally bounded to the strongest candidates; otherwise hundreds of symbols x
    # multi-timeframe REST calls make NORMAL+SCALP slow and can approach API limits.
    deep_cap = FULL_MARKET_DEEP_CANDIDATES if full_market else DEEP_CANDIDATES
    deep = preliminary[:max(1, deep_cap)]
    btc_item=next((x for x in preliminary if x['symbol']=='BTCUSDT'),None)
    if btc_item and all(x['symbol']!='BTCUSDT' for x in deep): deep = list(deep) + [btc_item]
    btc_context=None
    if btc_item:
        try:
            btc_d = klines('BTCUSDT','D',180)
            btc_4h = klines('BTCUSDT','240',180)
            btc_1h = klines('BTCUSDT','60',180)
            btc_context={'symbol':'BTCUSDT','bd':bias(btc_d),'b4':bias(btc_4h),'b1':bias(btc_1h)}
        except Exception:
            btc_context=None
    scored=[]
    with ThreadPoolExecutor(max_workers=max(2, FULL_MARKET_WORKERS)) as ex:
        futures={ex.submit(_deep_one,item,interval,btc_context,entry_threshold,strategy):item for item in deep}
        for fut in as_completed(futures):
            item=futures[fut]
            try:
                a=fut.result(); a.update({'symbol':item['symbol'],'turnover24h':item['turnover24h'],'enriched':False}); scored.append(a)
            except Exception as e:
                failures.append({'symbol':item['symbol'],'stage':'deep','error':str(e)})

    scored.sort(key=lambda x:x['score'], reverse=True)
    micro_targets=[x for x in scored if x['symbol']!='BTCUSDT' and float(x.get('score',0)) >= max(0, entry_threshold-10)][:MICRO_CANDIDATES]
    if not micro_targets and scored: micro_targets=scored[:MICRO_CANDIDATES]
    micro_map={}
    with ThreadPoolExecutor(max_workers=4) as ex:
        futures={ex.submit(flow_features,x['symbol']):x['symbol'] for x in micro_targets}
        for fut in as_completed(futures):
            s=futures[fut]
            try: micro_map[s]=fut.result()
            except Exception as e: failures.append({'symbol':s,'stage':'micro','error':str(e)})

    results=[]
    for x in scored:
        s=x['symbol']
        if s in micro_map:
            try:
                item=next(i for i in deep if i['symbol']==s)
                frames={k: klines(s, k, 180) for k in ('5','15','60','240','D')}
                a=score(frames,interval,micro=micro_map[s],live_price=item['price'],btc_context=btc_context,entry_threshold=entry_threshold,strategy=strategy)
                a.update({'symbol':s,'turnover24h':x['turnover24h'],'enriched':True}); results.append(a)
                continue
            except Exception as e: failures.append({'symbol':s,'stage':'rescore','error':str(e)})
        x.pop('frames',None); results.append(x)
    results.sort(key=lambda x:x.get('score',x.get('hint',0)), reverse=True)
    # News is a contextual filter, not an independent signal. A headline only blocks
    # when relevance is high and BTC/market reaction confirms it.
    try:
        news = news_snapshot()
        for x in results:
            apply_news_to_signal(x, news, strategy=strategy)
    except Exception as e:
        failures.append({'stage':'news','error':str(e)})
        news = {'status':'error','impact':'unknown','items':[],'btc_reaction':{'strength':'unknown','pct_15m':0,'pct_30m':0}}
    return _json_safe({'ok':True,'mode':MODE,'setup_interval':interval,
            'universe_size':len(universe),'checked':len(top),'technical_checked':len(preliminary),'technical_target':len(top),'technical_skipped':max(0,len(top)-len(preliminary)),
            'deep_checked':len(deep),'deep_target':len(deep),'micro_checked':len(micro_map),'micro_target':len(micro_targets),
            'results':results,'failures':failures,
            'news': news,
            'entry_threshold': int(entry_threshold), 'strategy': strategy, 'scan_policy':{'universe':'all active USDT linear perpetuals','full_market':bool(full_market),
                           'technical_cap':None if full_market else int(limit_symbols), 'deep_cap':None if full_market else DEEP_CANDIDATES, 'micro_cap':MICRO_CANDIDATES,
                           'optimization':'full-market fast technical pass; bounded deep candidates; shared TTL market-data cache; microstructure/news enrichment is event-focused'}})

def _roll_day_locked():
    today = datetime.now(timezone.utc).date().isoformat()
    if _state['day'] != today:
        _state['day'] = today; _state['day_start_balance'] = _state['balance']; _state['loss_streak'] = 0; _state['last_loss_at'] = 0


def _paper_equity_locked(prices=None):
    prices = prices if prices is not None else _state.get('mark_prices', {})
    eq = _state['balance']; unreal = 0.0
    for t in _state['open']:
        p = prices.get(t['symbol'], t['entry'])
        gross = (p - t['entry']) * t['qty'] if t['side'] == 'LONG' else (t['entry'] - p) * t['qty']
        unreal += gross
    return eq + unreal, unreal


def set_paper_budget(amount):
    amount=float(amount)
    with _lock:
        if amount <= 0: raise ValueError('trading budget must be positive')
        if amount > _state['balance']: raise ValueError('trading budget cannot exceed current balance')
        reserved=sum(float(x.get('margin_required',0)) for x in _state['open'])
        if amount + 1e-9 < reserved: raise ValueError(f'budget cannot be below reserved margin ${reserved:.4f}')
        _state['trading_budget']=amount
        return paper_state()


_private_cache = {}
_private_cache_lock = threading.RLock()
_demo_last_good_state = None

def _private_cached(key, ttl):
    with _private_cache_lock:
        item = _private_cache.get(key)
        if item and time.time() - item[0] < ttl:
            return item[1]
    return None

def _private_put(key, value):
    with _private_cache_lock:
        _private_cache[key] = (time.time(), value)
    return value

def bybit_private_get(path, params, retries=PRIVATE_RETRY_COUNT):
    if MODE == 'demo':
        key, secret = DEMO_API_KEY, DEMO_API_SECRET
    elif MODE == 'live':
        key, secret = LIVE_API_KEY, LIVE_API_SECRET
    else:
        raise RuntimeError('Private Bybit API is disabled in paper mode')
    if not key or not secret: raise RuntimeError(f'{MODE.upper()} API key/secret are not configured')
    last_error = None
    for attempt in range(retries + 1):
        try:
            _pace_rest()
            r = _http.get(BASE + path, params=params, headers=_auth_headers('GET', path, params))
            if r.status_code in (429, 500, 502, 503, 504) and attempt < retries:
                retry_after = getattr(r, 'headers', {}).get('Retry-After')
                try:
                    delay = max(0.5, min(5.0, float(retry_after))) if retry_after else 0.8 * (2 ** attempt)
                except ValueError:
                    delay = 0.8 * (2 ** attempt)
                time.sleep(delay); continue
            r.raise_for_status()
            try:
                j = r.json()
            except ValueError:
                raise RuntimeError(f'Bybit returned invalid JSON (HTTP {r.status_code})')
            if j.get('retCode') != 0:
                raise RuntimeError(f"Bybit {j.get('retCode')}: {j.get('retMsg', 'API error')}")
            return j.get('result', {})
        except httpx.HTTPStatusError as e:
            last_error = RuntimeError(f'Bybit HTTP {e.response.status_code}')
        except httpx.RequestError as e:
            last_error = RuntimeError(f'Bybit connection error: {e}')
        except RuntimeError as e:
            last_error = e
        if attempt < retries:
            time.sleep(0.5 * (2 ** attempt))
    raise last_error or RuntimeError('Bybit private request failed')

def _capital_defaults():
    base = min(max(float(BOT_BASE_CAPITAL), BOT_CAPITAL_MIN), BOT_CAPITAL_MAX)
    step = max(0.01, float(PROFIT_LOCK_STEP))
    return base, step

def bot_capital_config():
    from journal import get_setting
    state = _sync_bot_capital()
    return {
        'ok': True,
        'deposit': round(float(state['base_capital']), 6),
        'working_capital': round(float(state['trading_capital']), 6),
        'locked_profit': round(float(state.get('locked_profit', 0.0)), 6),
        'profit_lock_step': round(float(get_setting('profit_lock_step', PROFIT_LOCK_STEP)), 6),
        'min_deposit': round(float(BOT_CAPITAL_MIN), 6),
        'max_deposit': round(float(BOT_CAPITAL_MAX), 6),
        'mode': MODE,
        'journal_preserved': True,
    }

def set_bot_capital(amount, profit_lock_step=None):
    """Change the virtual bot deposit without touching the exchange wallet or journal.

    A deposit change establishes a new virtual baseline. Existing closed-trade history
    remains intact; already locked profit is preserved. Open positions are protected by
    refusing a new baseline below their current stop-risk.
    """
    amount = float(amount)
    if not math.isfinite(amount) or amount < BOT_CAPITAL_MIN or amount > BOT_CAPITAL_MAX:
        raise ValueError(f'bot deposit must be between ${BOT_CAPITAL_MIN:g} and ${BOT_CAPITAL_MAX:g}')
    if profit_lock_step is not None:
        step = float(profit_lock_step)
        if not math.isfinite(step) or step <= 0:
            raise ValueError('profit_lock_step must be positive')
    else:
        step = float(PROFIT_LOCK_STEP)
    # Check currently open exchange risk before lowering the virtual capital.
    open_risk = 0.0
    if MODE in ('demo', 'live'):
        try:
            for x in _demo_positions():
                q = abs(float(x.get('size') or 0)); ep = float(x.get('avgPrice') or 0); sl = float(x.get('stopLoss') or 0)
                if q > 0 and ep > 0 and sl > 0:
                    open_risk += q * abs(ep - sl)
        except Exception:
            # If exchange sync is unavailable, do not silently accept a lower capital
            # setting that could invalidate the risk budget.
            if amount < float(_bot_capital_state().get('base_capital', amount)):
                raise ValueError('cannot lower bot deposit while exchange positions cannot be synchronized')
    if amount + 1e-9 < open_risk:
        raise ValueError(f'bot deposit ${amount:.2f} is below current open stop-risk ${open_risk:.2f}')
    from journal import get_setting, set_setting, realized_total
    state = _bot_capital_state()
    current_realized = realized_total(MODE) if MODE in ('demo', 'live') else float(state.get('realized_seen', 0.0))
    # Preserve locked profit and all journal history, but start the virtual capital
    # calculation from the newly selected deposit.
    state['base_capital'] = round(amount, 8)
    state['trading_capital'] = round(amount, 8)
    state['realized_baseline'] = round(current_realized, 8)
    state['realized_seen'] = round(current_realized, 8)
    state['last_capital_change_at'] = int(time.time() * 1000)
    state['version'] = 2
    set_setting('bot_capital_state', json.dumps(state, separators=(',', ':')))
    set_setting('bot_capital_deposit', amount)
    set_setting('profit_lock_step', step)
    return bot_capital_config()


def _bot_capital_state():
    """Persistent virtual trading capital; protected profit is never available for new risk."""
    from journal import get_setting, set_setting, realized_total
    base, step = _capital_defaults()
    raw = get_setting('bot_capital_state')
    if raw:
        try:
            state = json.loads(raw)
            if state.get('version') in (1, 2, 3):
                # v6.1 standardizes the virtual Demo trading capital at $10,000.
                # Migrate the old untouched $10 baseline once; afterwards the user
                # controlled value is preserved. This prevents a restart/deploy from
                # bringing the bot back to the old $10 default.
                if state.get('version') in (1, 2) and float(state.get('base_capital', 0) or 0) == 10.0 and BOT_BASE_CAPITAL >= 10000:
                    state['base_capital'] = round(min(max(float(BOT_BASE_CAPITAL), BOT_CAPITAL_MIN), BOT_CAPITAL_MAX), 8)
                    state['trading_capital'] = state['base_capital']
                    state['version'] = 3
                    state['last_capital_change_at'] = int(time.time() * 1000)
                    set_setting('bot_capital_state', json.dumps(state, separators=(',', ':')))
                return state
        except Exception:
            pass
    # Establish the baseline at the moment this feature is first enabled so old
    # Demo P&L cannot accidentally become new trading capital.
    baseline = realized_total(MODE) if MODE in ('demo', 'live') else 0.0
    state = {
        'version': 1,
        'base_capital': round(base, 8),
        'trading_capital': round(base, 8),
        'locked_profit': 0.0,
        'realized_baseline': round(baseline, 8),
        'realized_seen': round(baseline, 8),
        'last_lock_at': int(time.time() * 1000),
    }
    set_setting('bot_capital_state', json.dumps(state, separators=(',', ':')))
    return state


def _sync_bot_capital():
    """Apply exchange-authoritative realized net P&L to bot capital."""
    from journal import get_setting, set_setting, realized_total, sync_closed_pnl
    state = _bot_capital_state()
    if MODE in ('demo', 'live'):
        # Keep the virtual capital ledger synchronized automatically; UI/journal
        # requests must not be required for profit-locking to work. The account
        # cache is short-lived, so this does not hammer the endpoint every cycle.
        try:
            sync_closed_pnl(MODE, _demo_closed_pnl(100))
        except Exception:
            pass
    current = realized_total(MODE) if MODE in ('demo', 'live') else state['realized_seen']
    seen = float(state.get('realized_seen', state.get('realized_baseline', 0.0)))
    delta = current - seen
    if abs(delta) > 1e-12:
        state['trading_capital'] = max(0.0, float(state['trading_capital']) + delta)
        state['realized_seen'] = current
    base = float(state['base_capital'])
    step = max(0.01, float(get_setting('profit_lock_step', PROFIT_LOCK_STEP)))
    # Lock only realized net profit above the base. Losses reduce trading capital;
    # they never unlock previously protected profit.
    already_locked = float(state.get('locked_profit', 0.0))
    net_profit = float(state['trading_capital']) + already_locked - base
    target_locked = max(already_locked, math.floor(max(0.0, net_profit) / step) * step)
    if target_locked > already_locked + 1e-9:
        increase = target_locked - already_locked
        state['locked_profit'] = target_locked
        state['trading_capital'] = max(0.0, float(state['trading_capital']) - increase)
        state['last_lock_at'] = int(time.time() * 1000)
    state['trading_capital'] = round(max(0.0, float(state['trading_capital'])), 8)
    state['locked_profit'] = round(max(0.0, float(state.get('locked_profit', 0.0))), 8)
    state['realized_seen'] = round(current, 8)
    set_setting('bot_capital_state', json.dumps(state, separators=(',', ':')))
    return state


def _bot_capital_view(unrealized_pnl=0.0, reserved_margin=0.0):
    from journal import get_setting
    state = _sync_bot_capital()
    trading = float(state['trading_capital'])
    # Unrealized gains do not increase risk budget; unrealized losses do reduce it.
    risk_equity = max(0.0, trading + min(0.0, float(unrealized_pnl)))
    available = max(0.0, risk_equity - float(reserved_margin))
    return {
        'base_capital': round(float(state['base_capital']), 6),
        'trading_capital': round(trading, 6),
        'locked_profit': round(float(state['locked_profit']), 6),
        'bot_equity': round(risk_equity, 6),
        'bot_available_capital': round(available, 6),
        'profit_lock_step': round(float(get_setting('profit_lock_step', PROFIT_LOCK_STEP)), 6),
    }


def _demo_wallet():
    key = ('wallet',)
    cached = _private_cached(key, DEMO_ACCOUNT_CACHE_TTL)
    return cached if cached is not None else _private_put(key, bybit_private_get('/v5/account/wallet-balance', {'accountType':'UNIFIED','coin':'USDT'}))

def _demo_positions():
    key = ('positions',)
    cached = _private_cached(key, DEMO_ACCOUNT_CACHE_TTL)
    if cached is not None: return cached
    return _private_put(key, bybit_private_get('/v5/position/list', {'category':'linear','settleCoin':'USDT'}).get('list', []))

def _demo_closed_pnl(limit=100):
    key = ('closed_pnl', min(int(limit), 100))
    cached = _private_cached(key, DEMO_CLOSED_PNL_CACHE_TTL)
    if cached is not None: return cached
    return _private_put(key, bybit_private_get('/v5/position/closed-pnl', {'category':'linear','limit':min(int(limit), 100)}).get('list', []))

def _invalidate_demo_account_cache():
    with _private_cache_lock:
        for key in list(_private_cache):
            if key and key[0] in {'wallet','positions','closed_pnl'}:
                _private_cache.pop(key, None)


def _demo_pnl_snapshot(wallet, positions, closed):
    acct = (wallet.get('list') or [{}])[0]
    now_ms = int(time.time() * 1000)
    day_start_ms = int(datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp() * 1000)
    realized_7d = sum(float(x.get('closedPnl') or 0) for x in closed)
    realized_today = sum(float(x.get('closedPnl') or 0) for x in closed if int(x.get('updatedTime') or x.get('createdTime') or 0) >= day_start_ms)
    unrealized = sum(float(x.get('unrealisedPnl') or 0) for x in positions)
    # This is the account's current perp P&L view; it is intentionally separate from the bot's $100 budget.
    account_unrealized = float(acct.get('totalPerpUPL') or unrealized or 0)
    total_pnl_7d = realized_7d + account_unrealized
    daily_pnl = realized_today + account_unrealized
    reserved_margin = sum(abs(float(x.get('positionIM') or 0)) for x in positions)
    return {
        'realized_pnl_7d': round(realized_7d, 6),
        'realized_pnl_today': round(realized_today, 6),
        'unrealized_pnl': round(account_unrealized, 6),
        'total_pnl_7d': round(total_pnl_7d, 6),
        'daily_pnl': round(daily_pnl, 6),
        'daily_loss': round(max(0.0, -daily_pnl), 6),
        'reserved_margin': round(reserved_margin, 6),
        'day_start_ms': day_start_ms,
        'now_ms': now_ms,
    }


def _demo_available_usdt():
    result = _demo_wallet()
    lst = result.get('list', [])
    if not lst: raise RuntimeError('Demo wallet returned no UNIFIED account')
    acct = lst[0]
    available = acct.get('totalAvailableBalance')
    equity = acct.get('totalEquity')
    if available is None:
        for c in acct.get('coin', []):
            if c.get('coin') == 'USDT':
                available = c.get('availableToWithdraw') or c.get('walletBalance')
                equity = equity or c.get('equity')
                break
    return float(available or 0), float(equity or 0), result


def _demo_risk_qty(symbol, entry, sl, requested_leverage=None, risk_pct=None, return_details=False):
    available, equity, _ = _demo_available_usdt()
    risk_pct = float(DEMO_RISK_PCT if (risk_pct is None and MODE == 'demo') else LIVE_RISK_PCT if risk_pct is None else risk_pct)
    positions = [x for x in _demo_positions() if float(x.get('size') or 0) > 0]
    reserved_margin = sum(abs(float(x.get('positionIM') or 0)) for x in positions)
    unrealized = sum(float(x.get('unrealisedPnl') or 0) for x in positions)
    cap = _bot_capital_view(unrealized_pnl=unrealized, reserved_margin=reserved_margin)
    budget = min(cap['bot_available_capital'], available)
    risk_cash = min(equity, budget) * risk_pct / 100
    dist = abs(entry - sl)
    if dist <= 0: raise ValueError('invalid stop distance')
    leverage, constraints = _effective_leverage(symbol, requested_leverage)
    qty_step, min_qty, max_qty = _symbol_rules(symbol)
    qty = risk_cash / dist
    qty = _round_step(qty, qty_step) if qty_step else qty
    if max_qty > 0: qty = min(qty, max_qty)
    if constraints['min_notional'] > 0 and entry * qty < constraints['min_notional']:
        min_qty_for_notional = constraints['min_notional'] / entry
        qty_candidate = math.ceil(min_qty_for_notional / qty_step) * qty_step if qty_step else min_qty_for_notional
        candidate_risk = qty_candidate * dist
        if candidate_risk > risk_cash * 1.000001:
            raise ValueError(f'minimum Bybit order value {constraints["min_notional"]:g} USDT requires risk ${candidate_risk:.2f}, above allowed ${risk_cash:.2f}')
        qty = qty_candidate
    margin = entry * qty / leverage
    if margin > budget * MAX_MARGIN_FRACTION:
        qty = _round_step((budget * MAX_MARGIN_FRACTION * leverage) / entry, qty_step) if qty_step else (budget * MAX_MARGIN_FRACTION * leverage) / entry
        margin = entry * qty / leverage
    actual_risk = qty * dist
    if actual_risk > risk_cash * 1.000001:
        raise ValueError(f'position risk ${actual_risk:.2f} exceeds allowed ${risk_cash:.2f}')
    if qty <= 0 or (min_qty > 0 and qty < min_qty):
        raise ValueError(f'position too small for available bot capital (${budget:.2f})')
    total_open_risk = 0.0
    for x in positions:
        q = abs(float(x.get('size') or 0))
        ep = float(x.get('avgPrice') or 0)
        slx = float(x.get('stopLoss') or 0)
        if q <= 0 or ep <= 0:
            continue
        # Prefer the exchange-confirmed SL. If unavailable, do not pretend the risk is
        # smaller than it is: use the configured per-trade risk against position notional.
        if slx > 0:
            total_open_risk += q * abs(ep - slx)
        else:
            total_open_risk += q * ep * (risk_pct / 100)
    total_limit = min(equity, budget) * TOTAL_OPEN_RISK_PCT / 100
    if total_open_risk + actual_risk > total_limit + 1e-9:
        raise ValueError(f'total open risk ${total_open_risk + actual_risk:.2f} exceeds portfolio limit ${total_limit:.2f}')
    details = (qty, margin, available, equity, cap, leverage, constraints, actual_risk)
    return details if return_details else details[:5]


def _demo_guard_status(equity=None):
    # Use Bybit's actual closed PnL + current perp uPnL so the daily guard survives
    # Render restarts instead of depending on an in-memory start-equity snapshot.
    wallet = _demo_wallet()
    positions = [x for x in _demo_positions() if float(x.get('size') or 0) > 0]
    closed = _demo_closed_pnl(100)
    snap = _demo_pnl_snapshot(wallet, positions, closed)
    loss = snap['daily_loss']
    return loss, loss >= DEMO_MAX_DAILY_LOSS

def demo_open(d):
    if MODE not in ('demo', 'live'): raise ValueError('Exchange trading mode is not enabled')
    if MODE == 'live' and not LIVE_TRADING_ARMED: raise ValueError('LIVE trading is not armed')
    side = str(d['side']).upper(); symbol = str(d['symbol']).upper(); entry = float(d['entry']); sl = float(d['stop_loss']); tp = float(d['take_profit'])
    if side not in ('LONG','SHORT'): raise ValueError('side must be LONG or SHORT')
    if entry <= 0 or sl <= 0 or tp <= 0: raise ValueError('entry, stop_loss and take_profit must be positive')
    if side == 'LONG' and not (sl < entry < tp): raise ValueError('LONG requires stop_loss < entry < take_profit')
    if side == 'SHORT' and not (tp < entry < sl): raise ValueError('SHORT requires take_profit < entry < stop_loss')
    positions = [x for x in _demo_positions() if float(x.get('size') or 0) > 0]
    if len(positions) >= MAX_POSITIONS: raise ValueError(f'max {MAX_POSITIONS} demo positions')
    if any(x.get('symbol') == symbol for x in positions): raise ValueError('Position for this symbol already open')
    qty, margin, available, equity, cap, leverage, constraints, actual_risk = _demo_risk_qty(symbol, entry, sl, d.get('leverage'), d.get('risk_pct'), return_details=True)
    daily_loss, locked = _demo_guard_status(equity)
    limit = DEMO_MAX_DAILY_LOSS if MODE == 'demo' else LIVE_MAX_DAILY_LOSS
    if locked: raise ValueError(f'Daily loss limit reached: ${daily_loss:.2f} / ${limit:.2f}')
    # Set leverage first. Bybit returns 110043 when the requested leverage is
    # already set. That is a successful no-op for our purpose, so do not block
    # the order on it.
    bybit_private_post(
        '/v5/position/set-leverage',
        {'category':'linear','symbol':symbol,'buyLeverage':str(leverage),'sellLeverage':str(leverage)},
        allow_ret_codes={110043},
    )
    order = {
        'category':'linear','symbol':symbol,'side':'Buy' if side == 'LONG' else 'Sell','orderType':'Market','qty':str(qty),
        'positionIdx':0,'reduceOnly':False,'takeProfit':str(tp),'stopLoss':str(sl),
        'tpTriggerBy':'MarkPrice','slTriggerBy':'MarkPrice','orderLinkId':f'ai-{int(time.time()*1000)}'
    }
    result = bybit_private_post('/v5/order/create', order)
    _invalidate_demo_account_cache()
    try:
        from learning_engine import record_trade_meta
        record_trade_meta({
            'external_id': order.get('orderLinkId') or order.get('orderId'), 'order_id': order.get('orderId'), 'order_link_id': order.get('orderLinkId'), 'mode': MODE, 'symbol': symbol, 'side': side,
            'strategy': d.get('strategy'), 'score': d.get('score'), 'risk_pct': d.get('risk_pct'),
            'leverage': leverage, 'atr_pct': d.get('atr_pct'), 'market_regime': d.get('market_regime'),
            'entry_timing': d.get('entry_timing'), 'news_impact': d.get('news_impact'),
            'planned_risk': actual_risk, 'entry_price': entry, 'stop_loss': sl, 'take_profit': tp
        })
    except Exception:
        pass
    return {'mode':MODE,'ok':True,'symbol':symbol,'side':side,'qty':qty,'margin_required':margin,'available_balance':available,'equity':equity,'bot_capital':cap,'leverage':leverage,'actual_risk_usdt':actual_risk,'min_notional':constraints['min_notional'],'max_leverage':constraints['max_leverage'],'order':result}


def trade_monitor_snapshot():
    """Reassess currently open exchange positions without changing them.
    This is an event-aware decision aid: it never overrides the hard risk limits.
    """
    if MODE not in ('demo','live'):
        return {'ok': True, 'mode': 'paper', 'positions': []}
    positions = exchange_positions()
    news = news_snapshot()
    out=[]
    for p in positions:
        symbol=p.get('symbol'); side='LONG' if p.get('side')=='Buy' else 'SHORT'
        mark=float(p.get('markPrice') or p.get('avgPrice') or 0); avg=float(p.get('avgPrice') or 0)
        upnl=float(p.get('unrealisedPnl') or 0); margin=abs(float(p.get('positionIM') or 0));
        pnl_pct=(upnl/max(margin,1e-9))*100 if margin else 0.0
        try:
            k=klines(symbol,'5',60)
            ff=frame_features(k)
            ret_3=(float(k.close.iloc[-1])/float(k.close.iloc[-4])-1)*100 if len(k)>=4 else 0.0
            atr_pct=float(ff.atr_pct.iloc[-1])
            bias_5='LONG' if ret_3>0.15 else 'SHORT' if ret_3<-0.15 else 'NEUTRAL'
        except Exception as e:
            ret_3=0.0; atr_pct=0.0; bias_5='UNKNOWN'
        aligned=(bias_5==side)
        if pnl_pct >= 0.2 and aligned: decision='HOLD / TRAIL'
        elif pnl_pct < 0 and aligned: decision='HOLD / REASSESS'
        elif pnl_pct < -5 and not aligned: decision='EXIT REVIEW'
        else: decision='REASSESS'
        out.append({'symbol':symbol,'side':side,'avg_price':avg,'mark_price':mark,'unrealised_pnl':upnl,'pnl_on_margin_pct':round(pnl_pct,3),'momentum_5m_pct':round(ret_3,4),'momentum_bias_5m':bias_5,'atr_pct':round(atr_pct,3),'idea_aligned':aligned,'decision':decision,'news_status':news.get('status'),'news_impact':news.get('impact'),'hard_stop_note':'Hard capital/risk limits always override HOLD.'})
    return {'ok':True,'mode':MODE,'positions':out,'checked_at':int(time.time()*1000)}

def exchange_positions():
    return [x for x in bybit_private_get('/v5/position/list', {'category':'linear','settleCoin':'USDT'}).get('list', []) if float(x.get('size') or 0) > 0]

def close_position(symbol):
    if MODE not in ('demo','live'):
        raise ValueError('Exchange position closing is unavailable in paper mode')
    symbol = str(symbol).upper()
    positions = [x for x in exchange_positions() if x.get('symbol') == symbol]
    if not positions:
        raise ValueError(f'No open position for {symbol}')
    p = positions[0]
    qty = p.get('size')
    side = 'Sell' if p.get('side') == 'Buy' else 'Buy'
    result = bybit_private_post('/v5/order/create', {
        'category':'linear','symbol':symbol,'side':side,'orderType':'Market','qty':str(qty),
        'positionIdx':int(p.get('positionIdx') or 0),'reduceOnly':True,'closeOnTrigger':True,
        'orderLinkId':f'ai-close-{int(time.time()*1000)}'
    })
    _invalidate_demo_account_cache()
    return {'mode':MODE,'ok':True,'symbol':symbol,'closed_qty':qty,'order':result}

def demo_state():
    global _demo_last_good_state
    if MODE not in ('demo','live'): return {'mode':'paper','configured':False}
    api_key, api_secret = (DEMO_API_KEY, DEMO_API_SECRET) if MODE == 'demo' else (LIVE_API_KEY, LIVE_API_SECRET)
    if not api_key or not api_secret:
        return {'mode':MODE,'configured':False,'error':f'{MODE.upper()} API key/secret missing'}
    warnings = []
    try:
        wallet = _demo_wallet()
    except Exception as e:
        # Do not replace a valid last-known account view with zeros during a transient
        # Bybit/network failure. Returning stale-but-explicit data keeps the UI trustworthy.
        if _demo_last_good_state is not None:
            stale = dict(_demo_last_good_state)
            stale['degraded'] = True
            stale['stale'] = True
            stale['warnings'] = list(stale.get('warnings') or []) + [f'Баланс временно не обновлён: {e}']
            return stale
        return {'mode':MODE,'configured':True,'degraded':True,'error':'wallet_sync_failed','error_detail':str(e),'warnings':['Не удалось получить баланс Demo. Повторная попытка будет выполнена автоматически.']}
    try:
        positions = [x for x in _demo_positions() if float(x.get('size') or 0) > 0]
    except Exception as e:
        positions = []
        warnings.append(f'Позиции временно недоступны: {e}')
    try:
        closed = _demo_closed_pnl(100)
    except Exception as e:
        closed = []
        warnings.append(f'История P&L временно недоступна: {e}')

    acct = (wallet.get('list') or [{}])[0]
    coin = next((x for x in acct.get('coin', []) if x.get('coin') == 'USDT'), {})
    equity = float(acct.get('totalEquity') or 0)
    usdt_wallet = float(coin.get('walletBalance') or 0)
    available_margin = float(acct.get('totalAvailableBalance') or 0)
    snap = _demo_pnl_snapshot(wallet, positions, closed)
    daily_loss = snap['daily_loss']
    locked = daily_loss >= (DEMO_MAX_DAILY_LOSS if MODE == 'demo' else LIVE_MAX_DAILY_LOSS)
    cap = _bot_capital_view(unrealized_pnl=snap['unrealized_pnl'], reserved_margin=snap['reserved_margin'])
    budget = cap['base_capital']
    bot_available = min(cap['bot_available_capital'], available_margin)
    state = {
        'mode':MODE,'configured':True,'degraded':bool(warnings),'stale':False,'warnings':warnings,
        'wallet':wallet,'positions':positions,'closed_pnl':closed[:20],
        'max_positions':MAX_POSITIONS,'trading_budget':budget,'bot_available_budget':round(bot_available, 6),
        'base_capital':cap['base_capital'],'trading_capital':cap['trading_capital'],'locked_profit':cap['locked_profit'],
        'bot_equity':cap['bot_equity'],'bot_available_capital':cap['bot_available_capital'],'profit_lock_step':cap['profit_lock_step'],
        'reserved_margin':snap['reserved_margin'],'daily_loss_limit':(DEMO_MAX_DAILY_LOSS if MODE == 'demo' else LIVE_MAX_DAILY_LOSS),'daily_loss':daily_loss,
        'daily_pnl':snap['daily_pnl'],'realized_pnl_today':snap['realized_pnl_today'],
        'realized_pnl_7d':snap['realized_pnl_7d'],'unrealized_pnl':snap['unrealized_pnl'],
        'total_pnl_7d':snap['total_pnl_7d'],'equity':equity,'usdt_wallet_balance':usdt_wallet,
        'available_margin':available_margin,'risk_pct':DEMO_RISK_PCT,'leverage':LEVERAGE,'risk_locked':locked,
    }
    _demo_last_good_state = dict(state)
    return state

def demo_account_state():
    return demo_state()

def paper_state():
    with _lock:
        _roll_day_locked()
        s = {k: (v.copy() if isinstance(v, list) else v) for k, v in _state.items()}
        realized_pnl = s['balance'] - s['initial_balance']
        _, unrealized_pnl = _paper_equity_locked()
        total_pnl = realized_pnl + unrealized_pnl
        s['realized_pnl'] = round(realized_pnl, 4)
        s['unrealized_pnl'] = round(unrealized_pnl, 4)
        s['pnl'] = round(total_pnl, 4)
        s['return_pct'] = round(total_pnl / s['initial_balance'] * 100, 3)
        daily_pnl = s['balance'] - s['day_start_balance']
        s['daily_pnl'] = round(daily_pnl, 4)
        s['daily_loss_pct'] = round(max(0.0, -daily_pnl) / max(s['day_start_balance'], 1e-9) * 100, 3)
        for t in s['open']:
            mark = s.get('mark_prices', {}).get(t['symbol'], t['entry'])
            gross = (mark - t['entry']) * t['qty'] if t['side'] == 'LONG' else (t['entry'] - mark) * t['qty']
            t['mark_price'] = round(mark, 10)
            t['unrealized_pnl'] = round(gross, 6)
            t['unrealized_pnl_pct'] = round(gross / max(t.get('margin_required', 1e-9), 1e-9) * 100, 3)
        # Paper mode uses the same protected-profit concept in memory so it can be tested
        # without an exchange account.
        base = START_BALANCE
        locked = max(0.0, math.floor(max(0.0, total_pnl) / max(PROFIT_LOCK_STEP, 0.01)) * max(PROFIT_LOCK_STEP, 0.01))
        locked = min(locked, max(0.0, s['balance'] - base + locked))
        s['base_capital'] = round(base, 6)
        s['locked_profit'] = round(locked, 6)
        s['trading_capital'] = round(max(0.0, s['balance'] - locked), 6)
        s['bot_equity'] = round(max(0.0, s['trading_capital'] + min(0.0, unrealized_pnl)), 6)
        s['bot_available_capital'] = round(max(0.0, s['bot_equity'] - s['reserved_margin']), 6)
        s['profit_lock_step'] = round(max(PROFIT_LOCK_STEP, 0.01), 6)
        s['risk_locked'] = s['daily_loss_pct'] >= DAILY_LOSS_LIMIT_PCT or s['loss_streak'] >= MAX_CONSECUTIVE_LOSSES
        wins = sum(1 for t in _state['trades'] if t.get('pnl', 0) > 0); losses = sum(1 for t in _state['trades'] if t.get('pnl', 0) < 0)
        s['win_rate'] = round(wins / max(1, wins + losses) * 100, 2)
        s['profit_factor'] = round(sum(max(0, t.get('pnl', 0)) for t in _state['trades']) / max(1e-9, sum(-min(0, t.get('pnl', 0)) for t in _state['trades'])), 2) if losses else None
        s['open_count'] = len(_state['open']); s['max_positions'] = MAX_POSITIONS; s['leverage'] = LEVERAGE; s['trading_budget'] = round(min(s.get('trading_budget', s['balance']), s['balance']), 6); s['reserved_margin'] = round(sum(float(x.get('margin_required',0)) for x in _state['open']), 6); s['available_margin_budget'] = round(max(0.0, s['trading_budget'] - s['reserved_margin']), 6); s['mode'] = MODE; s['risk_pct_default'] = RISK_PCT_DEFAULT; s['assumptions'] = {'fee_rate': PAPER_FEE_RATE, 'slippage_rate': PAPER_SLIPPAGE_RATE, 'leverage': LEVERAGE}
        return s


def _round_step(value, step):
    if not step or step <= 0: return value
    return math.floor(value / step) * step

def _symbol_rules(symbol):
    try:
        source = instruments()
    except Exception:
        return 0.0, 0.0, 0.0
    for x in source:
        if x.get('symbol') == symbol:
            lot = x.get('lotSizeFilter') or {}
            return float(lot.get('qtyStep') or 0), float(lot.get('minOrderQty') or 0), float(lot.get('maxOrderQty') or 0)
    return 0.0, 0.0, 0.0

def _symbol_constraints(symbol):
    # Exchange constraints used before an order is sent.
    try:
        source = instruments()
    except Exception:
        return {'min_notional': 0.0, 'min_leverage': 1.0, 'max_leverage': 0.0, 'leverage_step': 1.0, 'tick_size': 0.0}
    for x in source:
        if x.get('symbol') == symbol:
            lot = x.get('lotSizeFilter') or {}
            lev = x.get('leverageFilter') or {}
            price = x.get('priceFilter') or {}
            return {
                'min_notional': float(lot.get('minNotionalValue') or 0),
                'min_leverage': float(lev.get('minLeverage') or 1),
                'max_leverage': float(lev.get('maxLeverage') or 0),
                'leverage_step': float(lev.get('leverageStep') or 1),
                'tick_size': float(price.get('tickSize') or 0),
            }
    return {'min_notional': 0.0, 'min_leverage': 1.0, 'max_leverage': 0.0, 'leverage_step': 1.0, 'tick_size': 0.0}

def _effective_leverage(symbol, requested=None):
    requested = float(requested if requested is not None else LEVERAGE)
    if requested <= 0: raise ValueError('leverage must be positive')
    c = _symbol_constraints(symbol)
    max_lev = c['max_leverage']
    if max_lev and requested > max_lev:
        if LEVERAGE_MODE == 'auto':
            requested = max_lev
        else:
            raise ValueError(f'leverage {requested:g}x is unavailable for {symbol}; Bybit max is {max_lev:g}x')
    requested = max(c['min_leverage'], requested)
    step = c['leverage_step'] or 1.0
    requested = math.floor(requested / step) * step
    if max_lev and requested > max_lev + 1e-9: requested = max_lev
    return requested, c

def paper_open(d):
    side = str(d['side']).upper(); symbol = str(d['symbol']).upper(); entry = float(d['entry']); sl = float(d['stop_loss']); tp = float(d['take_profit']); risk_pct = float(d.get('risk_pct', RISK_PCT_DEFAULT))
    if side not in ('LONG', 'SHORT'): raise ValueError('side must be LONG or SHORT')
    if not symbol.endswith('USDT'): raise ValueError('symbol must be a USDT perpetual')
    if entry <= 0 or sl <= 0 or tp <= 0: raise ValueError('prices must be positive')
    if not 0 < risk_pct <= 50: raise ValueError('risk_pct must be between 0 and 50')
    if side == 'LONG' and not (sl < entry < tp): raise ValueError('LONG requires SL < entry < TP')
    if side == 'SHORT' and not (tp < entry < sl): raise ValueError('SHORT requires TP < entry < SL')
    with _lock:
        _roll_day_locked()
        if _state['balance'] <= 0: raise ValueError('balance depleted')
        if (_state['day_start_balance'] - _state['balance']) / max(_state['day_start_balance'], 1e-9) * 100 >= DAILY_LOSS_LIMIT_PCT: raise ValueError('daily loss limit reached')
        if _state['loss_streak'] >= MAX_CONSECUTIVE_LOSSES: raise ValueError('loss streak lock active')
        if _state['last_loss_at'] and time.time() - _state['last_loss_at'] < LOSS_COOLDOWN_SEC: raise ValueError('cooldown active after loss')
        if len(_state['open']) >= MAX_POSITIONS: raise ValueError(f'max {MAX_POSITIONS} open positions')
        if any(x['symbol'] == symbol for x in _state['open']): raise ValueError('position for this symbol already open')
        dist = abs(entry - sl); current_unrealized = _paper_equity_locked()[1]; locked = max(0.0, math.floor(max(0.0, (_state['balance'] - _state['initial_balance'] + current_unrealized)) / max(PROFIT_LOCK_STEP, 0.01)) * max(PROFIT_LOCK_STEP, 0.01)); trading_capital = max(0.0, _state['balance'] - locked); risk = max(0.0, trading_capital + min(0.0, current_unrealized)) * risk_pct / 100
        qty = risk / dist
        step, min_qty, max_qty = _symbol_rules(symbol)
        qty = _round_step(qty, step) if step else qty
        if max_qty > 0: qty = min(qty, max_qty)
        budget = min(_state.get('trading_budget', _state['balance']), trading_capital)
        reserved = sum(float(x.get('margin_required', 0)) for x in _state['open'])
        free_budget = max(0.0, budget - reserved)
        margin_required = entry * qty / LEVERAGE
        if margin_required > free_budget * MAX_MARGIN_FRACTION:
            allowed_margin = free_budget * MAX_MARGIN_FRACTION
            qty = _round_step((allowed_margin * LEVERAGE) / entry, step) if step else (allowed_margin * LEVERAGE) / entry
            margin_required = entry * qty / LEVERAGE
            risk = qty * dist
        if qty <= 0 or (min_qty > 0 and qty < min_qty): raise ValueError(f'position too small for available margin (${free_budget:.4f})')
        entry_exec = entry * (1 + PAPER_SLIPPAGE_RATE if side == 'LONG' else 1 - PAPER_SLIPPAGE_RATE)
        fee = entry_exec * qty * PAPER_FEE_RATE
        if fee > _state['balance'] * 0.05: raise ValueError('entry fee would be too large for current balance')
        _state['balance'] -= fee
        trade = {'id': len(_state['trades']) + len(_state['open']) + 1, 'symbol': symbol, 'side': side, 'entry': entry, 'entry_exec': entry_exec, 'stop_loss': sl, 'take_profit': tp, 'qty': qty, 'risk_usdt': risk, 'entry_fee': fee, 'leverage': LEVERAGE, 'notional': entry*qty, 'margin_required': margin_required, 'opened_at': int(time.time()*1000)}
        _state['open'].append(trade); _state['reserved_margin'] = sum(float(x.get('margin_required',0)) for x in _state['open'])
        return paper_state()


def paper_mark_to_market():
    try:
        t = tickers(); mp = {x['symbol']: float(x.get('lastPrice') or 0) for x in t}
    except Exception:
        return {'state': paper_state(), 'closed': []}
    closed = []
    with _lock:
        _roll_day_locked()
        for trade in list(_state['open']):
            price = mp.get(trade['symbol'])
            if not price: continue
            hit = None
            if trade['side'] == 'LONG':
                if price <= trade['stop_loss']: hit = ('SL', trade['stop_loss'])
                elif price >= trade['take_profit']: hit = ('TP', trade['take_profit'])
            else:
                if price >= trade['stop_loss']: hit = ('SL', trade['stop_loss'])
                elif price <= trade['take_profit']: hit = ('TP', trade['take_profit'])
            if hit:
                label, exit_price = hit
                exit_exec = exit_price * (1 - PAPER_SLIPPAGE_RATE if trade['side'] == 'LONG' else 1 + PAPER_SLIPPAGE_RATE)
                pnl = (exit_exec - trade['entry_exec']) * trade['qty'] if trade['side'] == 'LONG' else (trade['entry_exec'] - exit_exec) * trade['qty']
                exit_fee = abs(exit_exec * trade['qty']) * PAPER_FEE_RATE
                pnl -= exit_fee
                rec = {**trade, 'exit': exit_price, 'exit_exec': exit_exec, 'exit_fee': exit_fee, 'pnl': round(pnl, 6), 'result': label, 'closed_at': int(time.time() * 1000)}
                _state['balance'] += pnl; _state['trades'].append(rec); _state['open'].remove(trade); _state['reserved_margin'] = sum(float(x.get('margin_required',0)) for x in _state['open'])
                if pnl < 0: _state['loss_streak'] += 1; _state['last_loss_at'] = time.time()
                else: _state['loss_streak'] = 0
                closed.append(rec)
        _state['mark_prices'] = mp
        equity, unreal = _paper_equity_locked(mp); _state['peak_equity'] = max(_state['peak_equity'], equity)
    out = paper_state(); out['equity'] = round(equity, 6); out['unrealized_pnl'] = round(unreal, 6); out['drawdown_pct'] = round(max(0, (_state['peak_equity'] - equity) / max(_state['peak_equity'], 1e-9) * 100), 3)
    return {'state': out, 'closed': closed}


def paper_reset():
    with _lock:
        _state['balance'] = START_BALANCE; _state['initial_balance'] = START_BALANCE; _state['trading_budget'] = START_BALANCE; _state['reserved_margin'] = 0.0; _state['trades'] = []; _state['open'] = []
        _state['day'] = datetime.now(timezone.utc).date().isoformat(); _state['day_start_balance'] = START_BALANCE
        _state['loss_streak'] = 0; _state['last_loss_at'] = 0; _state['peak_equity'] = START_BALANCE; _state['mark_prices'] = {}
        return paper_state()
